package pm.login

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject
import pm.login.databinding.ActivityTorneiosBinding

class TorneiosActivity : AppCompatActivity() {

    private val binding by lazy {
        ActivityTorneiosBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val userId = intent.getIntExtra("user_id", -1)

        if (userId != -1) {
            fetchTorneios(userId)
        } else {
            Toast.makeText(this, "Erro ao carregar os torneios", Toast.LENGTH_SHORT).show()
        }
    }

    private fun fetchTorneios(userId: Int) {
        val url = "https://esan-tesp-ds-paw.web.ua.pt/tesp-ds-g32/api/torneios.php?user_id=$userId"

        val queue = Volley.newRequestQueue(this)
        val request = StringRequest(url,
            { response ->
                val jsonResponse = JSONObject(response)
                if (jsonResponse.getBoolean("success")) {
                    val torneios = jsonResponse.getJSONArray("torneios")
                    val torneiosList = ArrayList<JSONObject>()
                    for (i in 0 until torneios.length()) {
                        torneiosList.add(torneios.getJSONObject(i))
                    }

                    // Usar o adaptador personalizado
                    val adapter = TorneiosAdapter(this, torneiosList)
                    binding.torneiosListView.adapter = adapter

                } else {
                    Toast.makeText(this, jsonResponse.getString("message"), Toast.LENGTH_SHORT)
                        .show()
                }
            },
            { error ->
                Toast.makeText(this, "Erro: $error", Toast.LENGTH_SHORT).show()
            }
        )
        queue.add(request)
    }
}
