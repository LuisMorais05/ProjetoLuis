package pm.login

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import org.json.JSONObject

class TorneiosAdapter(private val context: Context, private val torneiosList: ArrayList<JSONObject>) : BaseAdapter() {

    override fun getCount(): Int = torneiosList.size

    override fun getItem(position: Int): JSONObject = torneiosList[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_torneio, parent, false)

        val torneio = getItem(position)
        val nome = torneio.getString("nome_torneio")
        val modalidade = torneio.getString("modalidade")
        val numeroEquipas = torneio.getInt("numero_equipas")
        val dataInicio = torneio.getString("data_inicio")
        val dataFim = torneio.getString("data_fim")

        val nomeTextView = view.findViewById<TextView>(R.id.torneio_nome)
        val verDetalhesButton = view.findViewById<Button>(R.id.ver_detalhes)

        nomeTextView.text = nome

        verDetalhesButton.setOnClickListener {
            val detalhes = """
                Nome: $nome
                Modalidade: $modalidade
                Número de Equipas: $numeroEquipas
                Data de Início: $dataInicio
                Data de Fim: $dataFim
            """.trimIndent()

            AlertDialog.Builder(context)
                .setTitle("Detalhes do Torneio")
                .setMessage(detalhes)
                .setPositiveButton("Fechar", null)
                .show()
        }

        return view
    }
}
