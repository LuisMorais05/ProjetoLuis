package pm.login

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import pm.login.databinding.ActivityMenuBinding

class MenuActivity : AppCompatActivity() {

    private val binding by lazy {
        ActivityMenuBinding.inflate(layoutInflater)
    }

    private var userId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        userId = intent.getIntExtra("user_id", -1)

        binding.btnViewTorneios.setOnClickListener {
            val intent = Intent(this, TorneiosActivity::class.java)
            intent.putExtra("user_id", userId)
            startActivity(intent)
        }
    }
}
