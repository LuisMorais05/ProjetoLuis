package pm.login

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import pm.login.databinding.ActivityCriarTorneioBinding

class CriarTorneioActivity : AppCompatActivity() {

    private val binding by lazy {
        ActivityCriarTorneioBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val userId = intent.getIntExtra("user_id", -1)

        binding.botaoCriarTorneio.setOnClickListener {
            val nome = binding.nomeTorneio.text.toString()
            val modalidade = binding.modalidadeTorneio.text.toString()
            val numeroEquipas = binding.numeroEquipas.text.toString()

            if (nome.isNotEmpty() && modalidade.isNotEmpty() && numeroEquipas.isNotEmpty()) {
                Toast.makeText(this, "Torneio criado com sucesso!", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
            }
        }
        var preferences = this.getSharedPreferences("pmLogin", Context.MODE_PRIVATE)
    binding.btnlogout.setOnClickListener{

        preferences.edit().putBoolean("login", false).apply()
        startActivity(Intent(this,MainActivity::class.java))
        finish()
    }



        // Configuração do menu inferior
        binding.menuVerTorneios.setOnClickListener {
            finish()
        }

        binding.menuCriarTorneio.setOnClickListener {
            Toast.makeText(this, "Você já está na página de criar torneio.", Toast.LENGTH_SHORT).show()
        }
    }
}

