package pm.login

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import pm.login.databinding.ActivityCriarTorneioBinding

class CriarTorneioActivity : AppCompatActivity() {

    private val binding by lazy {
        ActivityCriarTorneioBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val preferences = this.getSharedPreferences("pmLogin", Context.MODE_PRIVATE)
        val userId = preferences.getInt("user_id", -1) // Obtém o user_id armazenado no SharedPreferences

        // Configurar botão para criar torneio
        binding.botaoCriarTorneio.setOnClickListener {
            val queue = Volley.newRequestQueue(this)
            val url = "https://esan-tesp-ds-paw.web.ua.pt/tesp-ds-g32/api/torneios_create.php"

            val postRequest = object : StringRequest(Method.POST, url,
                { response ->
                    try {
                        Toast.makeText(this, response.toString(), Toast.LENGTH_SHORT).show()
                    } catch (e: JSONException) {
                        Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show()
                    }
                },
                { error: VolleyError ->
                    Toast.makeText(this, error.toString(), Toast.LENGTH_SHORT).show()
                }
            ) {
                override fun getParams(): MutableMap<String, String>? {
                    val params: MutableMap<String, String> = HashMap()
                    params["nome"] = binding.nomeTorneio.text.toString()
                    params["modalidade"] = binding.modalidadeTorneio.text.toString()
                    params["numerodeequipas"] = binding.numeroEquipas.text.toString()
                    params["user_id"] = userId.toString()
                    return params
                }
            }
            queue.add(postRequest)
        }

        binding.menuVerTorneios2.setOnClickListener {
            finish()
        }

        binding.menuCriarTorneio.setOnClickListener {
            Toast.makeText(this, "Você já está na página de criar torneio.", Toast.LENGTH_SHORT).show()
        }

        binding.menuPerfil.setOnClickListener {
            if (userId != -1) {
                startActivity(Intent(this, PerfilActivity::class.java).apply {
                    putExtra("user_id", userId) // Passa o user_id para a próxima Activity
                })
            } else {
                Toast.makeText(this, "Erro: Usuário não identificado!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
