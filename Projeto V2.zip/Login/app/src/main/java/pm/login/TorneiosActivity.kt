package pm.login

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject
import pm.login.databinding.ActivityTorneiosBinding

class TorneiosActivity : AppCompatActivity() {

    private val binding by lazy {
        ActivityTorneiosBinding.inflate(layoutInflater)
    }

    private val torneiosList = ArrayList<JSONObject>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

    var preferences = this.getSharedPreferences("pmLogin", Context.MODE_PRIVATE)
    var userId = preferences.getInt("user_id",0)

        if (userId != -1) {
            carregarTorneios(userId)

        } else {
            Toast.makeText(this, "Erro ao carregar os torneios.", Toast.LENGTH_SHORT).show()
        }

        // Configuração do menu inferior
        binding.menuVerTorneios2.setOnClickListener {
            Toast.makeText(this, "Você já está na página de torneios.", Toast.LENGTH_SHORT).show()
        }

        binding.menuPerfil.setOnClickListener {
            startActivity(Intent(this, PerfilActivity::class.java).apply {
                putExtra("user_id", userId)
            })
        }

        binding.menuCriarTorneio.setOnClickListener {
            startActivity(Intent(this, CriarTorneioActivity::class.java).apply {
                putExtra("user_id", userId)
            })
        }
    }

    private fun carregarTorneios(userId: Int) {
        val url = "https://esan-tesp-ds-paw.web.ua.pt/tesp-ds-g32/api/torneios.php?user_id=$userId"
        val queue = Volley.newRequestQueue(this)

        val request = StringRequest(url,
            { response ->
                try {
                    val jsonResponse = JSONObject(response)
                    if (jsonResponse.getBoolean("success")) {
                        val torneios = jsonResponse.getJSONArray("torneios")
                        torneiosList.clear()
                        for (i in 0 until torneios.length()) {
                            torneiosList.add(torneios.getJSONObject(i))
                        }

                        // Configurar o adapter personalizado
                        val adapter = TorneiosAdapter(this, torneiosList)
                        binding.torneiosListView.adapter = adapter
                    } else {
                        Toast.makeText(this, jsonResponse.getString("message"), Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Erro ao processar os torneios.", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Toast.makeText(this, "Erro de rede: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        )
        queue.add(request)
    }
}
