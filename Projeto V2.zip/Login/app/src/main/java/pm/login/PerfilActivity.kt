package pm.login

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject
import pm.login.databinding.ActivityPerfilBinding

class PerfilActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPerfilBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPerfilBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtém o ID do usuário dos SharedPreferences
        val preferences = this.getSharedPreferences("pmLogin", Context.MODE_PRIVATE)
        val userId = preferences.getInt("user_id", -1)

        if (userId != -1) {
            carregarDadosDoUsuario(userId)
        } else {
            Toast.makeText(this, "Erro ao carregar informações do usuário.", Toast.LENGTH_SHORT).show()
        }

        // Função de Logout
        binding.btnLogout.setOnClickListener {
            preferences.edit().putBoolean("login", false).apply()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        // Configuração do menu inferior
        binding.menuVerTorneios2.setOnClickListener {
            finish() // Retorna para a página de torneios
        }

        binding.menuCriarTorneio.setOnClickListener {
            startActivity(Intent(this, CriarTorneioActivity::class.java))
        }
    }

    private fun carregarDadosDoUsuario(userId: Int) {
        val url = "https://esan-tesp-ds-paw.web.ua.pt/tesp-ds-g32/api/get_user.php?user_id=$userId"
        val queue = Volley.newRequestQueue(this)

        val request = StringRequest(Request.Method.GET, url, { response ->
            try {
                val jsonResponse = JSONObject(response)
                if (jsonResponse.getBoolean("success")) {
                    val user = jsonResponse.getJSONObject("user")
                    exibirDadosDoUsuario(user)
                } else {
                    Toast.makeText(this, jsonResponse.getString("message"), Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Erro ao processar os dados do usuário.", Toast.LENGTH_SHORT).show()
            }
        }, { error ->
            Toast.makeText(this, "Erro de rede: ${error.message}", Toast.LENGTH_SHORT).show()
        })

        queue.add(request)
    }

    private fun exibirDadosDoUsuario(user: JSONObject) {
        val userIdTextView = findViewById<TextView>(R.id.textViewUserId)
        userIdTextView.text = "ID do usuário: ${user.getInt("id")}"

        // Adicione mais elementos à sua tela para exibir os outros campos, se necessário
        val userNameTextView = TextView(this).apply {
            text = "Nome: ${user.getString("name")}"
            textSize = 18f
        }

        val usernameTextView = TextView(this).apply {
            text = "Username: ${user.getString("username")}"
            textSize = 18f
        }

        val createdAtTextView = TextView(this).apply {
            text = "Criado em: ${user.getString("created_at")}"
            textSize = 18f
        }

        val roleTextView = TextView(this).apply {
            text = "Role: ${user.getString("role")}"
            textSize = 18f
        }

        binding.linearLayout.addView(userNameTextView)
        binding.linearLayout.addView(usernameTextView)
        binding.linearLayout.addView(createdAtTextView)
        binding.linearLayout.addView(roleTextView)
    }
}
