<?php

require_once 'config.php';

$pdo = connectDB($db);

// SQL query
$sql = "SELECT * FROM nv_destinos";
$stmt = $pdo->prepare($sql);
$stmt->execute();

$result = array();
$result['author'] = 'Nuno Veloso';
$result['language'] = 'PT';
$result['charset'] = 'UTF-8';
$result['destinos'] = array();

foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $tmp = array();
    $tmp['destino'] = $row['destino'];
    $tmp['preco'] = $row['preco'];
    $tmp['img'] = "https://esan-tesp-ds-paw.web.ua.pt/nveloso/img/".$row['img'];
    array_push( $result['destinos'], $tmp );
}

header('Content-Type: application/json');
echo json_encode($result);